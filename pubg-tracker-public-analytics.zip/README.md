# PUBG Tracker Public Analytics

Static public analytics page for PUBG Tracker.

## GitHub Pages

1. Put the contents of this folder into a folder such as `docs/` in the `Creighvan/Pubg-Tracker` repository.
2. Commit and push.
3. In GitHub, open **Settings → Pages**.
4. Choose **Deploy from a branch**, select your default branch, and select `/docs` as the folder.
5. Save.

GitHub will publish the site at the repository's Pages URL.

## Updating analytics

Edit `data.js` whenever the aggregate numbers change.

Add historical snapshots to `history`, for example:

`{ date: "2026-10-12", servers: 14, members: 510, trackedPlayers: 121 }`

Do not publish:
- Discord server IDs
- Player names
- Player IDs
- API keys
- Bot tokens
- Private server configuration
- Private analytics

The page intentionally uses aggregate statistics only.
