const d=window.PUBG_TRACKER_DATA;
document.getElementById("lastUpdated").textContent=d.updated;
document.getElementById("servers").textContent=d.servers;
document.getElementById("members").textContent=d.members;
document.getElementById("players").textContent=d.trackedPlayers;
document.getElementById("apiRate").textContent=d.expectedApiPlayersPerMinute;

const c=document.getElementById("usageChart"),ctx=c.getContext("2d");
function draw(){
  const r=c.getBoundingClientRect(),ratio=window.devicePixelRatio||1;
  c.width=r.width*ratio;c.height=r.height*ratio;ctx.setTransform(ratio,0,0,ratio,0,0);
  const w=r.width,h=r.height;
  ctx.clearRect(0,0,w,h);
  const hist=d.history||[];
  if(hist.length<2){
    ctx.fillStyle="#657184";ctx.font="13px system-ui";
    ctx.textAlign="center";ctx.fillText("Historical snapshots will appear here as data is collected.",w/2,h/2-4);
    ctx.font="11px system-ui";ctx.fillStyle="#4f5b6c";ctx.fillText("Current baseline: 13 servers · 481 members · 105 tracked players",w/2,h/2+20);
    return;
  }
  const vals=hist.map(x=>x.trackedPlayers),max=Math.max(...vals)*1.15,min=Math.min(...vals)*.85;
  const px=36,py=22,cw=w-px-12,ch=h-py-28;
  ctx.strokeStyle="#202936";ctx.lineWidth=1;
  for(let i=0;i<4;i++){const y=py+ch*i/3;ctx.beginPath();ctx.moveTo(px,y);ctx.lineTo(w-12,y);ctx.stroke();}
  ctx.strokeStyle="#7bd88f";ctx.lineWidth=3;ctx.beginPath();
  hist.forEach((x,i)=>{const xx=px+(cw*i/(hist.length-1)),yy=py+ch-(x.trackedPlayers-min)/(max-min)*ch;i?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy)});
  ctx.stroke();
}
window.addEventListener("resize",draw);draw();
