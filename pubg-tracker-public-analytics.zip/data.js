// Public, aggregate analytics only.
// Update these values from your bot when the numbers change.
// Do NOT put API keys, Discord IDs, player names, or private server data here.
window.PUBG_TRACKER_DATA = {
  updated: "October 5, 2026",
  servers: 13,
  members: 481,
  trackedPlayers: 105,
  expectedApiPlayersPerMinute: "5–15",
  history: [
    // Add a new snapshot when you update the public numbers:
    // { date: "2026-10-05", servers: 13, members: 481, players: 105 }
  ]
};
